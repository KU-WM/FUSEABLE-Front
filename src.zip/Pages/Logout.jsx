import React from 'react';
import '../css/Login.css';


function Logout () {
  return (
    <div>
      kakaoLogin
    </div>
  )
}

export default Logout;